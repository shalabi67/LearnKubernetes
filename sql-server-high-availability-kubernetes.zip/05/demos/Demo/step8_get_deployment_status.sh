# Get the status of the nodes, pods and service
kubectl get all