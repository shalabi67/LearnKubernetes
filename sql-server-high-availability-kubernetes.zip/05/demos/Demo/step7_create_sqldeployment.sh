# Deploy the SQL Server 2019 container

kubectl apply -f sqlAGPdeployment.yaml --record

kubectl apply -f sqlAGS1deployment.yaml --record

kubectl apply -f sqlAGS2deployment.yaml --record