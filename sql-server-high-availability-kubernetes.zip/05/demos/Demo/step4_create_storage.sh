# Create external storage with PV and PVC
kubectl apply -f sqlAGstorage.yaml
