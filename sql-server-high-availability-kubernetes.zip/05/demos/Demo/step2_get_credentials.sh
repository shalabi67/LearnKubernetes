# Get credentials for the cluster
az aks get-credentials --resource-group SQLAGRG --name SQLAG