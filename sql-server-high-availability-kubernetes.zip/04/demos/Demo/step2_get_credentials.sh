# Get credentials for the cluster
az aks get-credentials --resource-group SQLCLRG --name SQLCL