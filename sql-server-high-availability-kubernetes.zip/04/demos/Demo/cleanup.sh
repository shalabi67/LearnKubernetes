# Delete the resource group and everything in it
az group delete --name SQLCLRG
