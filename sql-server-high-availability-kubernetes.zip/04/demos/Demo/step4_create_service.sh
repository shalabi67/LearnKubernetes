# Create the load balancing service
kubectl apply -f sqlloadbalancer.yaml --record