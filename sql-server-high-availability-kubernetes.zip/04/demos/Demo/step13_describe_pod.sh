# Get all of the running components
kubectl get all

# Describe the pod
echo .... 
echo POD DESCRIPTION
kubectl describe pod -l app=mssql