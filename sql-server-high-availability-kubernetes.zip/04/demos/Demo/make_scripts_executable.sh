# Set the execute attribute for all scripts in the directory
sudo chmod +x *.sh