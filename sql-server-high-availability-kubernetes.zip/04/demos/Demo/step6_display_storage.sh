# Display the persistent volume and claim
kubectl get pv
kubectl get pvc
