# Deploy the SQL Server 2019 container
kubectl apply -f sqldeployment.yaml --record
