# List nodes
kubectl get nodes