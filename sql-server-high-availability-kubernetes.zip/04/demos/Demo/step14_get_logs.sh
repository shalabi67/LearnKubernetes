# Display the container logs
kubectl logs -l app=mssql

