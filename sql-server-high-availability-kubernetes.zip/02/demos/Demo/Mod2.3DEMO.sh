# K8 SQL Server HA Module 2 - Docker DEMO commands

# Pull the SQL Server image from the Docker Hub
docker pull mcr.microsoft.com/mssql/server

# The following commands are only needed to be run once
# to enable running Docker without sudo
#sudo groupadd docker
#sudo usermod -aG docker $USER

# List Docker iamges
docker image ls

# Run the container - note the password - you use it to connect 
docker run -e 'ACCEPT_EULA=Y' -e 'SA_PASSWORD=yourStrong(!)Password' -p 1433:1433 -d mcr.microsoft.com/mssql/server

# List the running containers - note container ID
docker ps

# To clean up replace [containerID] with ID from Docker ps command
docker stop [containerID]
docker rm [containerID]