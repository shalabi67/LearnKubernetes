# Get services - show IP addresses
kubectl get services