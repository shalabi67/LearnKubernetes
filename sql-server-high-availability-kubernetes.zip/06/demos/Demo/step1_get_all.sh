# Reteive all of the information for the deployment
kubectl get all 
