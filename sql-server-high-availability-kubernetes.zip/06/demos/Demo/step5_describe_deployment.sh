# Describe a deployment
echo Descibe deployment...
kubectl describe deployments


