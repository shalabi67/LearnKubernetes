# Generic command for opening the dashboard
#kubectl proxy
# Open the brower with the following URL:
#http://localhost:8001/api/v1/namespaces/kube-system/services/https:kubernetes-dashboard:/proxy/

# AKS dashboard
az aks browse --resource-group SQLAGRG --name SQLAG

