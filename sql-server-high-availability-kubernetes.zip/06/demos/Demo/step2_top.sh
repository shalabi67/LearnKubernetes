# Get the current resource usage
# Top nodes
echo Show the top node utilization
kubectl top nodes
echo
# Top
echo Show the top pod utilization
kubectl top pods
