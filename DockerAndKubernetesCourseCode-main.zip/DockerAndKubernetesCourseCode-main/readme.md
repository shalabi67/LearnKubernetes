## Docker and Kubernetes Course

https://codewithdan.com/products/docker-kubernetes

View the **Kubernetes for Developers: Core Concepts** video course on Pluralsight:

https://app.pluralsight.com/library/courses/kubernetes-developers-core-concepts/table-of-contents