## Prometheus Example

1. Run `kubectl create -f prometheus.deployment.yml`
2. Visit http://localhost
3. Get more details on Prometheus at https://prometheus.io/docs/prometheus/latest/getting_started/ and
    https://devopscube.com/setup-prometheus-monitoring-on-kubernetes/

