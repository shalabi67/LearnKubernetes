## Instructions

Run `kubectl create` or `kubectl apply` on the appropriate Job/CronJob.

An online tool that can be used experiment with the Cron format can be found at https://crontab.guru.