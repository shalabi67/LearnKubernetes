using System;

namespace AspNetCorePostgreSQLDockerApp.Models {
  
  public class DockerCommandExample {
    public int Id { get; set; }
    public string Example { get; set; }
    public string Description { get; set; }
  }
  
}