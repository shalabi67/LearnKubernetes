## Docker and Kubernetes Core Concepts Labs

These labs are for the Docker and Kubernetes Core Concepts instructor-led course:

https://codewithdan.com/products/docker-kubernetes

View the **Kubernetes for Developers: Core Concepts** video course on Pluralsight:

https://app.pluralsight.com/library/courses/kubernetes-developers-core-concepts/table-of-contents
