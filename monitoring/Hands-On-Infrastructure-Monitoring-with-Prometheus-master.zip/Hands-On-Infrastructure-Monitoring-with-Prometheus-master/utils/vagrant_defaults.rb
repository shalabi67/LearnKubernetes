# -*- mode: ruby -*-
# vi: set ft=ruby :

GUI     = false
RAM     = 512
DOMAIN  = ".prom.inet"
NETWORK = "192.168.42."
NETMASK = "255.255.255.0"
BOX     = 'bento/ubuntu-18.04'
