// Package v1 contains API Schema definitions for the example v1 API group
// +k8s:deepcopy-gen=package,register
// +groupName=example.com
package v1
